﻿
namespace Demo.Views
{
    public class View2Model
    {
        public string PageTitle { get; set; }
    }
}

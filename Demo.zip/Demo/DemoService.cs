﻿
namespace Demo
{
    public class DemoService : IDemoService
    {
        public string GetValue()
        {
            return "From Demo Custom";
        }
    }
}
